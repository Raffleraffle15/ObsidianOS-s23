# ObsidianOS S23 One-Click Builder

Upload this repo to GitHub, mark it as a template, then use GitHub Actions to build your privacy-hardened ROM in the cloud.
